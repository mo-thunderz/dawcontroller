// DAW Control - server code
//
//-------------------------------configurable params---------------------------------
const midi_if_input = "DAWIN"
const midi_if_output = "DAWOUT"

//-------------------------------internal params-------------------------------------
const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server);

// comment below needed for inclusion of relative statements in HTML file (public dir)
app.use(express.static(__dirname + '/public'));

// setup client file
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html');
});

// start server
server.listen(3000, () => {
  console.log('listening on *:3000');
});

//----------------------------------setup MIDI INPUT----------------------------------------

const midi = require('midi');

// Set up a new input.
const input = new midi.Input();

// Scan through available input ports.
for (let i = 0; i < input.getPortCount(); i++) {
	// console.log(input.getPortName(i));
	if (input.getPortName(i).startsWith(midi_if_input)) {
		input.openPort(i);
		console.log("INPUT: " + input.getPortName(i));
		input.ignoreTypes(false, false, false);			// filter for (Sysex, Timing, Active Sensing) -> set false to receive message
	}
}

//----------------------------------setup MIDI OUTPUT----------------------------------------

// Set up a new output.
const output = new midi.Output();

// Scan through available output ports.
for (let i = 0; i < output.getPortCount(); i++) {
	// console.log(output.getPortName(i));
	if (output.getPortName(i).startsWith(midi_if_output)) {
		output.openPort(i);
		console.log("OUTPUT: " + output.getPortName(i));
	}
}

//-------------------------------------callback functions------------------------------------
// callback function for information received from client (to be sent out as MIDI)
io.on('connection', (socket) => {
  socket.on('midi', (msg) => {
	// io.emit('midi', msg);			// mirror back to client (for testing without MIDI)
	// console.log(msg);
	// console.log(IntToMidi(msg));
	output.sendMessage(IntToMidi(msg));
  });
});

// Configure a callback for MIDI messages received.
input.on('message', (deltaTime, message) => {
  console.log(`m: ${message} d: ${deltaTime}`);

  if (message.length == 3) {					// standard MIDI message
	  io.emit('midi', MidiToInt(message));
  }
  if (message.length == 64) {					// Sysex message with names
	if (message[0] == 240 && message[5] == 18 && message[6] == 0) {
		var tr1 = ""; var tr2 = "";	var tr3 = ""; var tr4 = "";
		var tr5 = ""; var tr6 = "";	var tr7 = ""; var tr8 = "";
		for (let i = 0; i < 6; i++) {
			tr1 = tr1 + String.fromCharCode(message[7+i]);
			tr2 = tr2 + String.fromCharCode(message[14+i]);
			tr3 = tr3 + String.fromCharCode(message[21+i]);
			tr4 = tr4 + String.fromCharCode(message[28+i]);
			tr5 = tr5 + String.fromCharCode(message[35+i]);
			tr6 = tr6 + String.fromCharCode(message[42+i]);
			tr7 = tr7 + String.fromCharCode(message[49+i]);
			tr8 = tr8 + String.fromCharCode(message[56+i]);
		}
		io.emit('midi', tr1 + tr2 + tr3 + tr4 + tr5 + tr6 + tr7 + tr8);		// concatinate names of all tracks and send to client(s)
	}
  }
});

//-------------------------------------useful functions------------------------------------

function MidiToInt(message) {
  return (message[0] << 16) + (message[1] << 8) + message[2];
}

function IntToMidi(x) {
	var message = [0, 0, 0];
	message[0] = (x >> 16) & 255;
	message[1] = (x >> 8) & 255;
	message[2] = (x) & 255;
	return message;
}

//-------------------------------------Backup------------------------------------

// Close the MIDI input port when done.
//setTimeout(function() {
//  input.closePort();
//}, 100000);

// Send a MIDI message.
// output.sendMessage([144,22,1]);

// Close the MIDI output port when done.
// output.closePort();

